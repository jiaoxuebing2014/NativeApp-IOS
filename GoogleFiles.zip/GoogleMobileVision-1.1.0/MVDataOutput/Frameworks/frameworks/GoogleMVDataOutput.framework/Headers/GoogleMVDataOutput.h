// Generated umbrella header for GoogleMVDataOutput.

#import "GMVDataOutput.h"
#import "GMVFocusingDataOutput.h"
#import "GMVLargestFaceFocusingDataOutput.h"
#import "GMVMultiDataOutput.h"
#import "GMVMultiDetectorDataOutput.h"
#import "GMVOutputTrackerDelegate.h"
